# Assembly-Programming-Package
Tools in Package: Notepad++, DOSBox, NASM &amp; AFD
---
+ Just download the SFX (*AsseT.exe*), extract it anywhere you want, and start programming!
+ To do that, click on **AsseT.exe** in the list of files given above, and then click the **Download** button at the right side of the screen.
+ After extraction, you have to run the shortcut named *code* to get started. Some other instructions are given in the *readme.txt* file.
+ This package has been designed primarily for students of **FAST-NUCES** studying the Computer Organisation & Assembly Language (**COAL**) course.
+ Don't forget to star and share about this repository if you find this package helpful. :)

## Also check out XIDE - an online assembly programming platform ([Repo](https://github.com/ASD0x41/xide)). Just go to [https://xide.nullprime.com](https://xide.nullprime.com) in your browser and start coding!

**DISCLAIMER: The given tools belong to their respective owners. I have only bundled them together and written some NppExec scripts to make it easier for students to program in assembly in the course of their studies.**
